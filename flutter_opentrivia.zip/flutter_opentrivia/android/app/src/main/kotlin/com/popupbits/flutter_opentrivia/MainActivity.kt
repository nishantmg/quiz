package com.popupbits.flutter_opentrivia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
